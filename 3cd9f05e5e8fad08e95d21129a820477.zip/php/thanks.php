<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Fitness club</title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet" />
    <link href="css/owl.theme.css" rel="stylesheet" />
    <link href="css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="css/cookie.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<div class="site">

    <!--Start Header-->
    <header class="tz-header">

        <!--Start header top-->
        <div class="tz-header-top">
            <div class="container">

                <!--Header top left-->
                <div class="tz-header-top-left pull-left">

                    <ul class="top-header-menu pull-left">
                        <li>
                            <a href="index.php">Main</a>
                        </li>
                        <li>
                            <a href="blog.php"> Articles</a>
                        </li>
                        <li>
                            <a href="contact.php">Contacts</a>
                        </li>
                        <li>
                            <a href="policy.php">Privacy policy</a>
                        </li>
                        <li>
                            <a href="terms.php">Terms and conditions</a>
                        </li>
                    </ul>
                </div>
                <!--End header top left-->
                <div class="tz-header-top-right pull-right">
                    <ul class="top-header-social pull-right">
                        <li>
                            <a href="#"><i  class="fa fa-facebook-square"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-google"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </li>
                    </ul>
                    <div class="tz-hotline pull-right"><i class="fa fa-phone"></i>+6991611571297</div>
                </div>
            </div>
        </div>
        <!--End header top-->

        <!--Header Content-->

        <!--Header end content-->

        <!--Header menu-->

        <!--End header menu-->

    </header>
    <!--End header-->

    <!--Heading-->

    <!--End Heading-->

    <!--Control-->

    <!--End control-->

    <!--Blog wrap-->
    <div class="blog-post-sidebar">

        <!--Blog post-->
        <div class="blog-post">
            <div class="container">
                <div class="row">

                    <div class="col-md-10 border-left">
                        <article class="single-post">

							Thank you for your application!



                        </article>
                    </div>
                </div><!--End row-->
            </div><!--End container-->
        </div>
        <!--End blog post-->

    </div>
    <!--End blog wrap-->

    <footer class="tz-footer">


        <div class="tz-copyright">
            <div class="container">
                <p class="pull-left copyright-content">Copyright &copy;<script>document.write(new Date().getFullYear());</script>
                    All rights reserved</p>
                <ul class="pull-right footer-social">
                    <li>
                        <a href="#"><i  class="fa fa-facebook-square"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-google"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-dribbble"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-behance"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
    <!--End Footer-->
    <div class='cookie-banner'>
        <p>
            The site uses cookies. They allow us to recognize you and get information about your user experience.By continuing to browse the site, I agree to the use of cookies by the site owner in accordance with  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Cookie policy</a>
        </p>
        <button class='close-cookie'>&times;</button>
    </div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/theia-sticky-sidebar.js"></script>
<script src="js/off-canvas.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/custom.js"></script>
<script src="js/jquery-3.2.1.min.js"></script>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>

</body>
</html>