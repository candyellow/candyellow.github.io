<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Morning jog</title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet" />
    <link href="css/owl.theme.css" rel="stylesheet" />
    <link href="css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="css/cookie.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<div class="site">

    <!--Start Header-->
    <header class="tz-header">

        <!--Start header top-->
        <div class="tz-header-top">
            <div class="container">

                <!--Header top left-->
                <div class="tz-header-top-left pull-left">

                    <ul class="top-header-menu pull-left">
                        <li>
                            <a href="index.php">Main</a>
                        </li>
                        <li>
                            <a href="blog.php"> Articles</a>
                        </li>
                        <li>
                            <a href="contact.php">Contacts</a>
                        </li>
                        <li>
                            <a href="policy.php">Privacy policy</a>
                        </li>
                        <li>
                            <a href="terms.php">Terms and conditions</a>
                        </li>
                    </ul>
                </div>
                <!--End header top left-->
                <div class="tz-header-top-right pull-right">
                    <ul class="top-header-social pull-right">
                        <li>
                            <a href="#"><i  class="fa fa-facebook-square"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-google"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </li>
                    </ul>
                    <div class="tz-hotline pull-right"><i class="fa fa-phone"></i>+1513169145118</div>
                </div>
            </div>
        </div>
        <!--End header top-->

        <!--Header Content-->

        <!--Header end content-->

        <!--Header menu-->

        <!--End header menu-->

    </header>
        <!--End header-->

        <!--Heading-->

        <!--End Heading-->

        <!--Control-->

        <!--End control-->

        <!--Page wrap-->
        <div class="page-contact-wrap">

            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="contact-info">
                        <span class="icon">
                            <i class="fa fa-phone"></i>
                        </span>
                            <strong>+1513169145118</strong>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-info">
                        <span class="icon">
                            <i class="fa fa-map-marker"></i>
                        </span>
                            <strong>487 Huel Causeway
Hazelmouth, VT 89855</strong>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-info">
                        <span class="icon">
                            <i class="fa fa-envelope-o"></i>
                        </span>
                            <strong>efrain.botsford@yahoo.com</strong>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="contact-form">
                    <h3>Contacts</h3>

                    <form class="form-content row" action="thanks.php">
                        <div class="col-md-6">
                            <p class="comment-for-author">
                                <label>Name</label>
                                <input type="text" class="author" value="">
                            </p>
                            <p class="comment-for-email">
                                <label>Email</label>
                                <input type="email" class="email" value="">
                            </p>
                            <p class="comment-for-email">
                                <label>Phone number</label>
                                <input type="text" class="email" value="">
                            </p>

                        </div>
                        <div class="col-md-6">
                            <p class="comment-for-content">
                                <label></label>
                                <textarea style="margin-top: 43px;" class="comment" name="comment"></textarea>
                            </p>
                            <p class="comment-for-submit" style="text-align: left!important;">
                                <input type="checkbox" name="terms" value="check" required="" style="width: 20px;  height: 20px;
    display: block!important;"/>
                                <a href="policy.php" target="_blank">
                                    I have read and agree to the terms of the user agreement
                                </a>

                            </p>
                            <p class="comment-for-submit" style="text-align: left!important;">

                                <button name="submit" type="submit" id="submit" class="submit" >Send</button>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--End Page wrap-->

        <!--Start Footer-->
        <footer class="tz-footer">


            <div class="tz-copyright">
                <div class="container">
                    <p class="pull-left copyright-content">Copyright &copy;<script>document.write(new Date().getFullYear());</script>
                        All rights reserved</p>
                    <ul class="pull-right footer-social">
                        <li>
                            <a href="#"><i  class="fa fa-facebook-square"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-google"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
        <!--End Footer-->
        <div class='cookie-banner'>
            <p>
                The site uses cookies. They allow us to recognize you and get information about your user experience.By continuing to browse the site, I agree to the use of cookies by the site owner in accordance with  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Cookie policy</a>
            </p>
            <button class='close-cookie'>&times;</button>
        </div>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/theia-sticky-sidebar.js"></script>
    <script src="js/off-canvas.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/jquery-3.2.1.min.js"></script>

    <script>
        window.onload = function () {
            $('.close-cookie').click(function () {
                $('.cookie-banner').fadeOut();
            })
        }
    </script>
    <script>
        let elems = document.querySelectorAll('.server-name');
        elems.forEach((elem) => {
            elem.innerHTML = window.location.hostname
        })
    </script>

</body>
</html>