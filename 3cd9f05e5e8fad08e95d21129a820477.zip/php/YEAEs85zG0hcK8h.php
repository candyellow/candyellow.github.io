<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Rocker</title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet" />
    <link href="css/owl.theme.css" rel="stylesheet" />
    <link href="css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="css/cookie.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<div class="site">

    <!--Start Header-->
    <header class="tz-header">

        <!--Start header top-->
        <div class="tz-header-top">
            <div class="container">

                <!--Header top left-->
                <div class="tz-header-top-left pull-left">

                    <ul class="top-header-menu pull-left">
                        <li>
                            <a href="index.php">Main</a>
                        </li>
                        <li>
                            <a href="blog.php"> Articles</a>
                        </li>
                        <li>
                            <a href="contact.php">Contacts</a>
                        </li>
                        <li>
                            <a href="policy.php">Privacy policy</a>
                        </li>
                        <li>
                            <a href="terms.php">Terms and conditions</a>
                        </li>
                    </ul>
                </div>
                <!--End header top left-->
                <div class="tz-header-top-right pull-right">
                    <ul class="top-header-social pull-right">
                        <li>
                            <a href="#"><i  class="fa fa-facebook-square"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-google"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </li>
                    </ul>
                    <div class="tz-hotline pull-right"><i class="fa fa-phone"></i>+1927895540346</div>
                </div>
            </div>
        </div>
        <!--End header top-->

        <!--Header Content-->

        <!--Header end content-->

        <!--Header menu-->

        <!--End header menu-->

    </header>
        <!--End header-->

        <!--Heading-->

        <!--End Heading-->

        <!--Control-->

        <!--End control-->

        <!--Blog wrap-->
        <div class="blog-post-sidebar">

            <!--Blog post-->
            <div class="blog-post">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 blog-sidebar">
                            <div class="widget widget_search">
                                <form>
                                    <input type="text" name="s" value="" >
                                    <i class="icon-search fa fa-search"></i>
                                </form>
                            </div>

                            <div class="widget">
                                <div class="tz-title-filter">
                                    <h3 class="tz-title">
                                        <span>Popular</span>
                                    </h3>
                                    <div class="tz-cat-filter tz-cat-filter2">

                                    </div>
                                </div>
                                <div class="widget-ca-box">
                                    <ul class="widget-post-box">

                                        
                                        <li>
                                            <div class="widget_thumbnail">
                                                <a href="Jn3YmZvhMYvUiN6G7Qf0X58C1.php">
                                                    <img src="./assets/images/jonathan-borba-vtcadj-wfoa-unsplash.jpg" >
                                                </a>
                                            </div>
                                            <div class="widget_item_info">
                                                <h4><a href="Jn3YmZvhMYvUiN6G7Qf0X58C1.php">What is Calisthenics(calisthenics)?</a></h4>
                                                <span class="meta">Nella / 29.03.2021</span>
                                            </div>
                                        </li>
                                        

                                        <li>
                                            <div class="widget_thumbnail">
                                                <a href="YEAEs85zG0hcK8h.php">
                                                    <img src="./assets/images/meghan-holmes-buwcs7g1_28-unsplash.jpg" >
                                                </a>
                                            </div>
                                            <div class="widget_item_info">
                                                <h4><a href="YEAEs85zG0hcK8h.php">TOP 5 FITNESS TIPS FROM RHYTHM</a></h4>
                                                <span class="meta">Nella / 29.03.2021</span>
                                            </div>
                                        </li>
                                        

                                        <li>
                                            <div class="widget_thumbnail">
                                                <a href="9f7fbf1723a816c628b21f423739185c.php">
                                                    <img src="./assets/images/victor-freitas-fzsfqu2a-mk-unsplash.jpg" >
                                                </a>
                                            </div>
                                            <div class="widget_item_info">
                                                <h4><a href="9f7fbf1723a816c628b21f423739185c.php">My most favorite workout! The Club Tryouts</a></h4>
                                                <span class="meta">Nella / 29.03.2021</span>
                                            </div>
                                        </li>
                                        

                                    </ul>
                                </div>
                            </div>

                        </div>
                        <div class="col-md-9 border-left">
                            <article class="single-post">
                                <div class="tz-single-thumbnail">
                                    <img src="./assets/images/meghan-holmes-buwcs7g1_28-unsplash.jpg" >
                                </div>
                                <h1 class="single-title">TOP 5 FITNESS TIPS FROM RHYTHM</h1>
                                <span class="post-meta">Nella /  29.03.2021 </span>
                                <div class="post-content">
                                    <p><strong>TOP 5 FITNESS TIPS FROM RHYTHM</strong> "Every man strives to achieve in everything he does, but at the same time avoid failure. The desire to try something new often leads to the feeling that it is difficult or useless, but the main thing is not to give up. The main strength of any one of us is the ability to adapt to any situation and overcome it with perseverance and determination. This ability allows you to achieve success in any situation, regardless of the circumstances. Here are some simple tips that will help you overcome the feeling of stagnation and get closer to achieving your goals:1. Find a mentor. Any man can find a partner, even on the most difficult road. But it is better to find a coach, because the coach will always be ready with lessons and strategies from the master. The best thing is that the coach will always be able to refer to you when needed. mistakes. Yes, we all make them, but remember the legend about the yellow brick road? It's not always the destination that matters, but the result.2. Take ownership. A good coach will always be interested in your business acumen. So, don't be afraid if you don't have the right stuff, don't be afraid of heights and obstacles. Just work on yourself, solve your problems, and make progress happen. progress!3. Be yourself. It's hard to believe, but in order to be noticed, you need to be yourself. It's hard to imagine, but a young coach in his 20's will immediately go to work with a client. And in the Gym, on your own initiative, and with the right approach, you will make a significant contribution. Don't look for young ladies, gentlemen. It's not their place. Don't be afraid if you have a beard, a mustache, or just a few random muscles in your body. Show your assets. Don't hide behind your opponent's muscles. Show off in front of the mirror.4. Smile at everyone. Even your opponents. And try to be cheerful. Sometimes you just need to cheer up a little, take a warm shower, or just relax. Remember: you have the right to an opinion. Everyone is entitled to it.5. Warm up is more important than any other thing. Even for a beginner. It is better to warm up than to do nothing at all. It is better to work out for two in the gym. Yes, and this is not a directive from above, but from the bottom of your own heart. It is better to warm up than to bleach your body.And the most important tip…! Don't force weights. If you don't want to do something, don't do it. If you don't want to run, don't walk. If you don't want to jump, don't squeeze. If you don't want to lift a barbell, don't crush your head on a book. Everything that is written in the article is my personal opinion. I have made mistakes, I will correct them, but do not get mad at all because of this. friends. If you liked the article, please post it . This will help me understand how and why I make mistakes, and help fix them. Thank you.</p>

                                </div>
                                <div class="sing-post-footer">

                                    <div class="tz-share pull-right">

                                        <a href="#" class="fa fa-facebook-square"></a>
                                        <a href="#" class="fa fa-twitter"></a>
                                        <a href="#" class="fa fa-google"></a>
                                        <a href="#" class="fa fa-dribbble"></a>
                                        <a href="#" class="fa fa-behance"></a>
                                    </div>
                                </div>

                            </article>
                        </div>
                    </div><!--End row-->
                </div><!--End container-->
            </div>
            <!--End blog post-->

        </div>
        <!--End blog wrap-->

    <footer class="tz-footer">


        <div class="tz-copyright">
            <div class="container">
                <p class="pull-left copyright-content">Copyright &copy;<script>document.write(new Date().getFullYear());</script>
                    All rights reserved</p>
                <ul class="pull-right footer-social">
                    <li>
                        <a href="#"><i  class="fa fa-facebook-square"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-google"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-dribbble"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-behance"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
    <!--End Footer-->
    <div class='cookie-banner'>
        <p>
            The site uses cookies. They allow us to recognize you and get information about your user experience.By continuing to browse the site, I agree to the use of cookies by the site owner in accordance with  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Cookie policy</a>
        </p>
        <button class='close-cookie'>&times;</button>
    </div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/theia-sticky-sidebar.js"></script>
<script src="js/off-canvas.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/custom.js"></script>
<script src="js/jquery-3.2.1.min.js"></script>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>

</body>
</html>