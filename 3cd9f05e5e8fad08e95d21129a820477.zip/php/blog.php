<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Burn calories</title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
          rel='stylesheet' type='text/css'>
    <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet"/>
    <link href="css/owl.theme.css" rel="stylesheet"/>
    <link href="css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="css/cookie.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<div class="site">

    <!--Start Header-->
    <header class="tz-header">

        <!--Start header top-->
        <div class="tz-header-top">
            <div class="container">

                <!--Header top left-->
                <div class="tz-header-top-left pull-left">

                    <ul class="top-header-menu pull-left">
                        <li>
                            <a href="index.php">Main</a>
                        </li>
                        <li>
                            <a href="blog.php"> Articles</a>
                        </li>
                        <li>
                            <a href="contact.php">Contacts</a>
                        </li>
                        <li>
                            <a href="policy.php">Privacy policy</a>
                        </li>
                        <li>
                            <a href="terms.php">Terms and conditions</a>
                        </li>
                    </ul>
                </div>
                <!--End header top left-->
                <div class="tz-header-top-right pull-right">
                    <ul class="top-header-social pull-right">
                        <li>
                            <a href="#"><i class="fa fa-facebook-square"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-google"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </li>
                    </ul>
                    <div class="tz-hotline pull-right"><i class="fa fa-phone"></i>+9935747101330</div>
                </div>
            </div>
        </div>
        <!--End header top-->

        <!--Header Content-->

        <!--Header end content-->

        <!--Header menu-->

        <!--End header menu-->

    </header>
    <!--End header-->

    <!--Heading-->

    <!--End Heading-->

    <!--Control-->

    <!--End control-->

    <!--Blog wrap-->
    <div class="blog-post-wrap">

        <!--Blog post for blog 3 column-->
        <div class="blog-post two-columns">
            <div class="container">
                <div class="row">

                    
                    <div class="col-md-6 col-sm-6" style="height: 500px">

                        <!--Item blog post-->
                        <div class="item-blog-post">
                            <div class="tz-post-thumbnail">
                                <img src="./assets/images/jonathan-borba-vtcadj-wfoa-unsplash.jpg" alt="column2" style="height: 270px; width: 100%;" >
                            </div>
                            <div class="tz-post-info">
                                <h3><a href="Jn3YmZvhMYvUiN6G7Qf0X58C1.php">What is Calisthenics(calisthenics)?</a></h3>
                                <span class="meta">Victor / 31.03.2021 </span>
                                <p>   Now most people burn their bridges with their own resources, by spending every weekend at home, procrastinating studies, and just generally not doi......</p>
                            </div>
                        </div>
                        <!--End Item blog post-->

                    </div>
                    

                    <div class="col-md-6 col-sm-6" style="height: 500px">

                        <!--Item blog post-->
                        <div class="item-blog-post">
                            <div class="tz-post-thumbnail">
                                <img src="./assets/images/meghan-holmes-buwcs7g1_28-unsplash.jpg" alt="column2" style="height: 270px; width: 100%;" >
                            </div>
                            <div class="tz-post-info">
                                <h3><a href="YEAEs85zG0hcK8h.php">TOP 5 FITNESS TIPS FROM RHYTHM</a></h3>
                                <span class="meta">Victor / 31.03.2021 </span>
                                <p>   "Every man strives to achieve in everything he does, but at the same time avoid failure. The desire to try something new often leads to the feeling......</p>
                            </div>
                        </div>
                        <!--End Item blog post-->

                    </div>
                    

                    <div class="col-md-6 col-sm-6" style="height: 500px">

                        <!--Item blog post-->
                        <div class="item-blog-post">
                            <div class="tz-post-thumbnail">
                                <img src="./assets/images/victor-freitas-fzsfqu2a-mk-unsplash.jpg" alt="column2" style="height: 270px; width: 100%;" >
                            </div>
                            <div class="tz-post-info">
                                <h3><a href="9f7fbf1723a816c628b21f423739185c.php">My most favorite workout! The Club Tryouts</a></h3>
                                <span class="meta">Victor / 31.03.2021 </span>
                                <p>   Summer isn't over yet, but it is already late. It is already time to get rid of the winter blues. It is already time to work on your feet, toss and......</p>
                            </div>
                        </div>
                        <!--End Item blog post-->

                    </div>
                    

                    <!--Item blog post-->

                    <!--End Item blog post-->

                </div>
            </div><!--End row-->
        </div><!--End container-->
    </div>
    <!--End blog post-->

    <!--Pagination-->
    <nav class="tz-pagination">
        <ul class="pagination_list">
            <li>
                <a class="prev" href="blog.php"><i class="fa fa-angle-left"></i></a>
            </li>
            <li>
                <a href="blog.php">1</a>
            </li>
            <li>
                <a href="blog.php">2</a>
            </li>
            <li>
                <span class="current">3</span>
            </li>
            <li>
                <span>...</span>
            </li>
            <li>
                <a href="blog.php">4</a>
            </li>
            <li>
                <a href="blog.php">5</a>
            </li>
            <li>
                <a class="next" href="blog.php"><i class="fa fa-angle-right"></i></a>
            </li>
        </ul>
    </nav>
    <!--End pagination-->

</div>
<!--End blog wrap-->

<!--Start Footer-->
<footer class="tz-footer">


    <div class="tz-copyright">
        <div class="container">
            <p class="pull-left copyright-content">Copyright &copy;<script>document.write(new Date().getFullYear());</script>
                All rights reserved
            </p>
            <ul class="pull-right footer-social">
                <li>
                    <a href="#"><i class="fa fa-facebook-square"></i></a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-google"></i></a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-dribbble"></i></a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-behance"></i></a>
                </li>
            </ul>
        </div>
    </div>
</footer>
<!--End Footer-->
<div class='cookie-banner'>
    <p>
        The site uses cookies. They allow us to recognize you and get information about your user experience.By continuing to browse the site, I agree to the use of cookies by the site owner in accordance with  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Cookie policy</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/theia-sticky-sidebar.js"></script>
<script src="js/off-canvas.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/custom.js"></script>
<script src="js/jquery-3.2.1.min.js"></script>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>

</body>
</html>