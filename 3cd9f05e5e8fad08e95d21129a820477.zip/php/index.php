<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Aerobics</title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet" />
    <link href="css/owl.theme.css" rel="stylesheet" />
    <link href="css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="css/cookie.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>

    <div class="site">

        <!--Start Header-->
        <header class="tz-header">

            <!--Start header top-->
            <div class="tz-header-top">
                <div class="container">

                    <!--Header top left-->
                    <div class="tz-header-top-left pull-left">

                        <ul class="top-header-menu pull-left">
                            <li>
                                <a href="index.php">Main</a>
                            </li>
                            <li>
                                <a href="blog.php"> Articles</a>
                            </li>
                            <li>
                                <a href="contact.php">Contacts</a>
                            </li>
                            <li>
                                <a href="policy.php">Privacy policy</a>
                            </li>
                            <li>
                                <a href="terms.php">Terms and conditions</a>
                            </li>
                        </ul>
                    </div>
                    <!--End header top left-->
                    <div class="tz-header-top-right pull-right">
                        <ul class="top-header-social pull-right">
                            <li>
                                <a href="#"><i  class="fa fa-facebook-square"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-google"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-dribbble"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-behance"></i></a>
                            </li>
                        </ul>
                        <div class="tz-hotline pull-right"><i class="fa fa-phone"></i>+3851644274140</div>
                    </div>
                </div>
            </div>
            <!--End header top-->

            <!--Header Content-->

            <!--Header end content-->

            <!--Header menu-->

            <!--End header menu-->

        </header>
        <!--End header-->

        <!--Heading-->

        <!--End Heading-->

        <!--Control-->

        <!--End control-->

        <!--Blog wrap-->
        <div class="blog-post-sidebar">

        <!--Blog post-->
        <div class="blog-post blog-border-widgets">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 tzright_style tzcontent">
                        <div class="item-thumbnail-wrap item-blog-heading">

                            
                            <div class="tz-thumbnail">
                                <a href="Jn3YmZvhMYvUiN6G7Qf0X58C1.php">
                                    <img src="./assets/images/jonathan-borba-vtcadj-wfoa-unsplash.jpg" >
                                </a>

                                <div class="tz-infomation">
                                    <h3 class="tz-post-title"><a href="single.php">What is Calisthenics(calisthenics)?</a></h3>
                                    <span class="meta">Jimmy / 08.04.2021 </span>
                                </div>
                            </div>
                            


                        </div>
                        <div class="item-list-style">
                            
                            <div class="row" style="margin-bottom: 150px!important">
                                <div class="col-md-4 col-sm-4">
                                    <div class="tz-thumbnail">
                                        <img src="./assets/images/jonathan-borba-vtcadj-wfoa-unsplash.jpg" style="height: 120px">
                                    </div>
                                </div>
                                <div class="col-md-8 col-sm-8">
                                    <div class="tz-infomation">
                                        <h3 class="tz-post-title"><a href="Jn3YmZvhMYvUiN6G7Qf0X58C1.php">What is Calisthenics(calisthenics)?</a></h3>
                                        <span class="meta"> Jimmy/   08.04.2021 </span>
                                        <p><strong></strong> Now most people burn their bridges with their own resources, by spending every weekend at home, procrastinating studies, and just ge... ...
                                        </p>
                                        <a href="Jn3YmZvhMYvUiN6G7Qf0X58C1.php" class="readmore">Read further</a>
                                    </div>
                                </div>
                            </div>
                            

                            <div class="row" style="margin-bottom: 150px!important">
                                <div class="col-md-4 col-sm-4">
                                    <div class="tz-thumbnail">
                                        <img src="./assets/images/meghan-holmes-buwcs7g1_28-unsplash.jpg" style="height: 120px">
                                    </div>
                                </div>
                                <div class="col-md-8 col-sm-8">
                                    <div class="tz-infomation">
                                        <h3 class="tz-post-title"><a href="YEAEs85zG0hcK8h.php">TOP 5 FITNESS TIPS FROM RHYTHM</a></h3>
                                        <span class="meta"> Jimmy/   08.04.2021 </span>
                                        <p><strong></strong> "Every man strives to achieve in everything he does, but at the same time avoid failure. The desire to try something new often leads... ...
                                        </p>
                                        <a href="YEAEs85zG0hcK8h.php" class="readmore">Read further</a>
                                    </div>
                                </div>
                            </div>
                            

                            <div class="row" style="margin-bottom: 150px!important">
                                <div class="col-md-4 col-sm-4">
                                    <div class="tz-thumbnail">
                                        <img src="./assets/images/victor-freitas-fzsfqu2a-mk-unsplash.jpg" style="height: 120px">
                                    </div>
                                </div>
                                <div class="col-md-8 col-sm-8">
                                    <div class="tz-infomation">
                                        <h3 class="tz-post-title"><a href="9f7fbf1723a816c628b21f423739185c.php">My most favorite workout! The Club Tryouts</a></h3>
                                        <span class="meta"> Jimmy/   08.04.2021 </span>
                                        <p><strong></strong> Summer isn't over yet, but it is already late. It is already time to get rid of the winter blues. It is already time to work on your... ...
                                        </p>
                                        <a href="9f7fbf1723a816c628b21f423739185c.php" class="readmore">Read further</a>
                                    </div>
                                </div>
                            </div>
                            

                        </div>


                        <!--Pagination-->
                        <nav class="tz-pagination">
                            <ul class="pagination_list">
                                <li>
                                    <a class="prev" href="index.php"><i class="fa fa-angle-left"></i></a>
                                </li>
                                <li>
                                    <a href="index.php">1</a>
                                </li>
                                <li>
                                    <a href="index.php">2</a>
                                </li>
                                <li>
                                    <span class="current">3</span>
                                </li>
                                <li>
                                    <span>...</span>
                                </li>
                                <li>
                                    <a href="index.php">4</a>
                                </li>
                                <li>
                                    <a href="index.php">5</a>
                                </li>
                                <li>
                                    <a class="next" href="index.php"><i class="fa fa-angle-right"></i></a>
                                </li>
                            </ul>
                        </nav>
                        <!--End pagination-->
                    </div>
                    <div class="col-md-3 tzright_sidebar tzsidebar">
                        <div class="widget widget_search">
                            <form>
                                <input type="text" name="s" value="" >
                                <i class="icon-search fa fa-search"></i>
                            </form>
                        </div>
                

                        <div class="widget">
                            <div class="tz-title-filter">
                                <h3 class="tz-title">
                                    <span>Popular</span>
                                </h3>

                            </div>
                            <div class="widget-ca-box">
                                <ul class="widget-post-box">

                                    
                                    <li>
                                        <div class="widget_thumbnail">
                                            <a href="Jn3YmZvhMYvUiN6G7Qf0X58C1.php">
                                                <img src="./assets/images/jonathan-borba-vtcadj-wfoa-unsplash.jpg" >
                                            </a>
                                        </div>
                                        <div class="widget_item_info">
                                            <h4><a href="Jn3YmZvhMYvUiN6G7Qf0X58C1.php">What is Calisthenics(calisthenics)?</a></h4>
                                            <span class="meta">Jimmy  08.04.2021 </span>
                                        </div>
                                    </li>
                                    

                                    <li>
                                        <div class="widget_thumbnail">
                                            <a href="YEAEs85zG0hcK8h.php">
                                                <img src="./assets/images/meghan-holmes-buwcs7g1_28-unsplash.jpg" >
                                            </a>
                                        </div>
                                        <div class="widget_item_info">
                                            <h4><a href="YEAEs85zG0hcK8h.php">TOP 5 FITNESS TIPS FROM RHYTHM</a></h4>
                                            <span class="meta">Jimmy  08.04.2021 </span>
                                        </div>
                                    </li>
                                    

                                    <li>
                                        <div class="widget_thumbnail">
                                            <a href="9f7fbf1723a816c628b21f423739185c.php">
                                                <img src="./assets/images/victor-freitas-fzsfqu2a-mk-unsplash.jpg" >
                                            </a>
                                        </div>
                                        <div class="widget_item_info">
                                            <h4><a href="9f7fbf1723a816c628b21f423739185c.php">My most favorite workout! The Club Tryouts</a></h4>
                                            <span class="meta">Jimmy  08.04.2021 </span>
                                        </div>
                                    </li>
                                    

                                </ul>
                            </div>
                        </div>


                    </div>
                </div><!--End row-->
            </div><!--End container-->
        </div>
        <!--End blog post-->

        </div>
        <!--End blog wrap-->

        <!--Start Footer-->
        <footer class="tz-footer">


            <div class="tz-copyright">
                <div class="container">
                    <p class="pull-left copyright-content">Copyright &copy;<script>document.write(new Date().getFullYear());</script>
                        All rights reserved</p>
                    <ul class="pull-right footer-social">
                        <li>
                            <a href="#"><i  class="fa fa-facebook-square"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-google"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
        <!--End Footer-->
        <div class='cookie-banner'>
            <p>
                The site uses cookies. They allow us to recognize you and get information about your user experience.By continuing to browse the site, I agree to the use of cookies by the site owner in accordance with  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Cookie policy</a>
            </p>
            <button class='close-cookie'>&times;</button>
        </div>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/theia-sticky-sidebar.js"></script>
    <script src="js/off-canvas.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/jquery-3.2.1.min.js"></script>
    <script>
        window.onload = function () {
            $('.close-cookie').click(function () {
                $('.cookie-banner').fadeOut();
            })
        }
    </script>
    <script>
        let elems = document.querySelectorAll('.server-name');
        elems.forEach((elem) => {
            elem.innerHTML = window.location.hostname
        })
    </script>

</body>
</html>